import React from 'react';
import Card from '../ui/Card';
import { WorkOrder } from '../../types';

interface RecentActivityProps {
  workOrders: WorkOrder[];
}

const RecentActivity: React.FC<RecentActivityProps> = ({ workOrders }) => {
  const recentlyUpdated = workOrders
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 5);

  const getActivityMessage = (workOrder: WorkOrder) => {
    switch (workOrder.status) {
      case 'assigned':
        return `Work order "${workOrder.title}" was assigned to ${workOrder.technicianName}`;
      case 'in-progress':
        return `${workOrder.technicianName} started working on "${workOrder.title}"`;
      case 'completed':
        return `"${workOrder.title}" was completed by ${workOrder.technicianName}`;
      case 'cancelled':
        return `Work order "${workOrder.title}" was cancelled`;
      default:
        return `Work order "${workOrder.title}" was updated`;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'assigned':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
        
        <div className="space-y-4">
          {recentlyUpdated.map((workOrder) => {
            const timeDiff = Date.now() - new Date(workOrder.updatedAt).getTime();
            const hours = Math.floor(timeDiff / (1000 * 60 * 60));
            const minutes = Math.floor(timeDiff / (1000 * 60));
            const timeAgo = hours > 0 ? `${hours}h ago` : `${minutes}m ago`;
            
            return (
              <div key={workOrder.id} className="flex items-start space-x-3 pb-4 border-b border-gray-100 last:border-b-0 last:pb-0">
                <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(workOrder.status)}`}>
                  {workOrder.status}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900">
                    {getActivityMessage(workOrder)}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {timeAgo} • {workOrder.customerName}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
        
        {recentlyUpdated.length === 0 && (
          <div className="text-center py-6 text-gray-500">
            <p>No recent activity to display</p>
          </div>
        )}
      </div>
    </Card>
  );
};

export default RecentActivity;