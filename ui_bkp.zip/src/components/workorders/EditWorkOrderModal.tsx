import React, { useState, useEffect } from 'react';
import Button from '../ui/Button';
import Card from '../ui/Card';
import PriorityBadge from '../ui/PriorityBadge';
import StatusBadge from '../ui/StatusBadge';
import { X, Calendar, Clock, MapPin, User, AlertCircle } from 'lucide-react';
import { WorkOrder, Customer, Technician } from '../../types';

interface EditWorkOrderModalProps {
  isOpen: boolean;
  workOrder: WorkOrder | null;
  customers: Customer[];
  technicians: Technician[];
  onClose: () => void;
  onUpdateWorkOrder: (workOrderId: string, updates: Partial<WorkOrder>) => void;
}

const EditWorkOrderModal: React.FC<EditWorkOrderModalProps> = ({
  isOpen,
  workOrder,
  customers,
  technicians,
  onClose,
  onUpdateWorkOrder
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'medium' as WorkOrder['priority'],
    status: 'assigned' as WorkOrder['status'],
    customerId: '',
    customerName: '',
    technicianId: '',
    technicianName: '',
    address: '',
    scheduledDate: '',
    estimatedDuration: 60
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Initialize form data when workOrder changes
  useEffect(() => {
    if (workOrder) {
      const scheduledDateTime = new Date(workOrder.scheduledDate);
      const formattedDateTime = scheduledDateTime.toISOString().slice(0, 16);

      setFormData({
        title: workOrder.title,
        description: workOrder.description,
        priority: workOrder.priority,
        status: workOrder.status,
        customerId: workOrder.customerId,
        customerName: workOrder.customerName,
        technicianId: workOrder.technicianId || '',
        technicianName: workOrder.technicianName || '',
        address: workOrder.location.address,
        scheduledDate: formattedDateTime,
        estimatedDuration: workOrder.estimatedDuration
      });
    }
  }, [workOrder]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (!formData.customerId) {
      newErrors.customerId = 'Customer is required';
    }

    if (!formData.scheduledDate) {
      newErrors.scheduledDate = 'Scheduled date and time is required';
    } else {
      const selectedDate = new Date(formData.scheduledDate);
      const now = new Date();
      if (selectedDate < now) {
        newErrors.scheduledDate = 'Scheduled date cannot be in the past';
      }
    }

    if (formData.estimatedDuration < 15) {
      newErrors.estimatedDuration = 'Duration must be at least 15 minutes';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || !workOrder) {
      return;
    }

    const selectedCustomer = customers.find(c => c.id === formData.customerId);
    const selectedTechnician = technicians.find(t => t.id === formData.technicianId);

    const updates: Partial<WorkOrder> = {
      title: formData.title,
      description: formData.description,
      priority: formData.priority,
      status: formData.status,
      customerId: formData.customerId,
      customerName: selectedCustomer?.name || formData.customerName,
      technicianId: formData.technicianId || undefined,
      technicianName: selectedTechnician?.name || undefined,
      location: {
        ...workOrder.location,
        address: formData.address
      },
      scheduledDate: new Date(formData.scheduledDate).toISOString(),
      estimatedDuration: formData.estimatedDuration,
      updatedAt: new Date().toISOString()
    };

    onUpdateWorkOrder(workOrder.id, updates);
    onClose();
  };

  const handleCustomerChange = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId);
    setFormData({
      ...formData,
      customerId,
      customerName: customer?.name || '',
      address: customer?.address || formData.address
    });
  };

  const handleTechnicianChange = (technicianId: string) => {
    const technician = technicians.find(t => t.id === technicianId);
    setFormData({
      ...formData,
      technicianId,
      technicianName: technician?.name || ''
    });
  };

  const availableTechnicians = technicians.filter(t => 
    t.status === 'available' || t.id === formData.technicianId
  );

  if (!isOpen || !workOrder) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Edit Work Order</h2>
            <p className="text-sm text-gray-600">Work Order #{workOrder.id}</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Current Status Display */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-2">Current Status</h3>
            <div className="flex items-center space-x-4">
              <StatusBadge status={workOrder.status} />
              <PriorityBadge priority={workOrder.priority} />
              {workOrder.technicianName && (
                <span className="text-sm text-gray-600">
                  Assigned to: {workOrder.technicianName}
                </span>
              )}
            </div>
          </div>

          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Title *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                  errors.title ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="Work order title"
              />
              {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Priority
              </label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value as WorkOrder['priority'] })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as WorkOrder['status'] })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                <option value="assigned">Assigned</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description *
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                errors.description ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="Detailed description of the work to be performed"
            />
            {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
          </div>

          {/* Customer Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Customer *
            </label>
            <select
              value={formData.customerId}
              onChange={(e) => handleCustomerChange(e.target.value)}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                errors.customerId ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Select a customer</option>
              {customers.map((customer) => (
                <option key={customer.id} value={customer.id}>
                  {customer.name} - {customer.slaLevel.toUpperCase()}
                </option>
              ))}
            </select>
            {errors.customerId && <p className="text-red-500 text-sm mt-1">{errors.customerId}</p>}
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <MapPin className="h-4 w-4 inline mr-1" />
              Service Address
            </label>
            <input
              type="text"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="Service location address"
            />
          </div>

          {/* Scheduling */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="h-4 w-4 inline mr-1" />
                Scheduled Date & Time *
              </label>
              <input
                type="datetime-local"
                value={formData.scheduledDate}
                onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                  errors.scheduledDate ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              {errors.scheduledDate && <p className="text-red-500 text-sm mt-1">{errors.scheduledDate}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Clock className="h-4 w-4 inline mr-1" />
                Estimated Duration (minutes)
              </label>
              <input
                type="number"
                min="15"
                step="15"
                value={formData.estimatedDuration}
                onChange={(e) => setFormData({ ...formData, estimatedDuration: parseInt(e.target.value) || 60 })}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                  errors.estimatedDuration ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              {errors.estimatedDuration && <p className="text-red-500 text-sm mt-1">{errors.estimatedDuration}</p>}
            </div>
          </div>

          {/* Technician Assignment */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <User className="h-4 w-4 inline mr-1" />
              Assigned Technician
            </label>
            <select
              value={formData.technicianId}
              onChange={(e) => handleTechnicianChange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
            >
              <option value="">Unassigned</option>
              {availableTechnicians.map((technician) => (
                <option key={technician.id} value={technician.id}>
                  {technician.name} - {technician.status} ({technician.activeWorkOrders.length} active jobs)
                </option>
              ))}
            </select>
            {availableTechnicians.length === 0 && (
              <div className="flex items-center mt-2 text-amber-600">
                <AlertCircle className="h-4 w-4 mr-1" />
                <span className="text-sm">No available technicians</span>
              </div>
            )}
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Update Work Order
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default EditWorkOrderModal;