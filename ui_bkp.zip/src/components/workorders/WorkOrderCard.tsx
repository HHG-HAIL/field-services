import React from 'react';
import { WorkOrder } from '../../types';
import StatusBadge from '../ui/StatusBadge';
import PriorityBadge from '../ui/PriorityBadge';
import Card from '../ui/Card';
import Button from '../ui/Button';
import { MapPin, Clock, User, Calendar, Edit, UserX } from 'lucide-react';

interface WorkOrderCardProps {
  workOrder: WorkOrder;
  onStatusChange?: (workOrderId: string, newStatus: WorkOrder['status']) => void;
  onAssignTechnician?: (workOrderId: string) => void;
  onEditWorkOrder?: (workOrder: WorkOrder) => void;
  onChangeTechnician?: (workOrder: WorkOrder) => void;
  showActions?: boolean;
}

const WorkOrderCard: React.FC<WorkOrderCardProps> = ({ 
  workOrder, 
  onStatusChange, 
  onAssignTechnician, 
  onEditWorkOrder,
  onChangeTechnician,
  showActions = true 
}) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const getStatusActions = () => {
    switch (workOrder.status) {
      case 'assigned':
        return [
          { label: 'Start Work', status: 'in-progress' as const, variant: 'primary' as const },
          { label: 'Cancel', status: 'cancelled' as const, variant: 'danger' as const }
        ];
      case 'in-progress':
        return [
          { label: 'Complete', status: 'completed' as const, variant: 'success' as const }
        ];
      default:
        return [];
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow duration-200">
      <div className="space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-gray-900 truncate">
              {workOrder.title}
            </h3>
            <p className="text-sm text-gray-600 mt-1 line-clamp-2">
              {workOrder.description}
            </p>
          </div>
          <div className="flex flex-col space-y-2 ml-4">
            <StatusBadge status={workOrder.status} />
            <PriorityBadge priority={workOrder.priority} />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-600">
          <div className="flex items-center">
            <User className="h-4 w-4 mr-2 text-gray-400" />
            <span className="truncate">
              {workOrder.technicianName || 'Unassigned'}
            </span>
          </div>
          
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2 text-gray-400" />
            <span>{formatDate(workOrder.scheduledDate)}</span>
          </div>
          
          <div className="flex items-center">
            <MapPin className="h-4 w-4 mr-2 text-gray-400" />
            <span className="truncate">{workOrder.customerName}</span>
          </div>
          
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-2 text-gray-400" />
            <span>{formatDuration(workOrder.estimatedDuration)}</span>
          </div>
        </div>

        <div className="text-xs text-gray-500">
          <div className="truncate">{workOrder.location.address}</div>
        </div>

        {showActions && (
          <div className="flex flex-wrap gap-2 pt-4 border-t border-gray-200">
            {/* Edit Work Order */}
            {onEditWorkOrder && (
              <Button
                size="sm"
                variant="secondary"
                onClick={() => onEditWorkOrder(workOrder)}
              >
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Button>
            )}

            {/* Change Technician */}
            {onChangeTechnician && (
              <Button
                size="sm"
                variant="secondary"
                onClick={() => onChangeTechnician(workOrder)}
              >
                <UserX className="h-4 w-4 mr-1" />
                {workOrder.technicianId ? 'Change Technician' : 'Assign Technician'}
              </Button>
            )}
            
            {/* Legacy assign technician button for backward compatibility */}
            {!workOrder.technicianId && onAssignTechnician && !onChangeTechnician && (
              <Button
                size="sm"
                variant="primary"
                onClick={() => onAssignTechnician(workOrder.id)}
              >
                Assign Technician
              </Button>
            )}
            
            {getStatusActions().map((action) => (
              <Button
                key={action.label}
                size="sm"
                variant={action.variant}
                onClick={() => onStatusChange?.(workOrder.id, action.status)}
              >
                {action.label}
              </Button>
            ))}
          </div>
        )}
      </div>
    </Card>
  );
};

export default WorkOrderCard;