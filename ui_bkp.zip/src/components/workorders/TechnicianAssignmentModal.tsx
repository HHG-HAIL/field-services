import React, { useState } from 'react';
import { Technician, WorkOrder } from '../../types';
import Button from '../ui/Button';
import { X, User, MapPin, Star, Clock, Wrench } from 'lucide-react';

interface TechnicianAssignmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAssign: (technicianId: string) => void;
  technicians: Technician[];
  workOrder: WorkOrder | null;
}

const TechnicianAssignmentModal: React.FC<TechnicianAssignmentModalProps> = ({
  isOpen,
  onClose,
  onAssign,
  technicians,
  workOrder
}) => {
  const [selectedTechnicianId, setSelectedTechnicianId] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');

  const handleAssign = () => {
    if (selectedTechnicianId) {
      onAssign(selectedTechnicianId);
      setSelectedTechnicianId('');
      setSearchTerm('');
      onClose();
    }
  };

  const calculateDistance = (tech: Technician) => {
    if (!tech.currentLocation || !workOrder?.location.coordinates) {
      return 0;
    }
    
    const R = 3959; // Earth's radius in miles
    const dLat = (workOrder.location.coordinates.lat - tech.currentLocation.lat) * Math.PI / 180;
    const dLon = (workOrder.location.coordinates.lng - tech.currentLocation.lng) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(tech.currentLocation.lat * Math.PI / 180) * Math.cos(workOrder.location.coordinates.lat * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return Math.round(R * c * 10) / 10; // Round to 1 decimal place
  };

  const getRelevantSkills = (tech: Technician) => {
    if (!workOrder) return [];
    
    const workOrderKeywords = [
      ...workOrder.title.toLowerCase().split(' '),
      ...workOrder.description.toLowerCase().split(' ')
    ];
    
    return tech.skills.filter(skill => 
      workOrderKeywords.some(keyword => 
        skill.toLowerCase().includes(keyword) || keyword.includes(skill.toLowerCase())
      )
    );
  };

  const getSuitabilityScore = (tech: Technician) => {
    let score = 0;
    
    // Availability bonus
    if (tech.status === 'available') score += 50;
    else if (tech.status === 'busy') score += 20;
    
    // Workload penalty
    score -= tech.activeWorkOrders.length * 10;
    
    // Skills relevance bonus
    const relevantSkills = getRelevantSkills(tech);
    score += relevantSkills.length * 15;
    
    // Distance penalty (closer is better)
    const distance = calculateDistance(tech);
    if (distance > 0) {
      score -= Math.min(distance * 2, 30); // Max 30 point penalty for distance
    }
    
    return Math.max(0, score);
  };

  const filteredTechnicians = technicians
    .filter(tech => {
      const matchesSearch = 
        tech.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tech.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchesSearch;
    })
    .sort((a, b) => getSuitabilityScore(b) - getSuitabilityScore(a));

  const getStatusColor = (status: Technician['status']) => {
    switch (status) {
      case 'available':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'busy':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'offline':
        return 'text-gray-600 bg-gray-50 border-gray-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getRecommendationBadge = (tech: Technician) => {
    const score = getSuitabilityScore(tech);
    if (score >= 70) return { label: 'Best Match', color: 'bg-green-100 text-green-800' };
    if (score >= 50) return { label: 'Good Match', color: 'bg-blue-100 text-blue-800' };
    if (score >= 30) return { label: 'Fair Match', color: 'bg-yellow-100 text-yellow-800' };
    return { label: 'Poor Match', color: 'bg-red-100 text-red-800' };
  };

  if (!isOpen || !workOrder) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" onClick={onClose} />

        <div className="inline-block w-full max-w-4xl p-6 my-8 text-left align-middle transition-all transform bg-white shadow-xl rounded-lg">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Assign Technician</h3>
              <p className="text-sm text-gray-600 mt-1">
                Select the best technician for: {workOrder.title}
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          {/* Work Order Summary */}
          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                <span>{workOrder.location.address}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-2 text-gray-400" />
                <span>{new Date(workOrder.scheduledDate).toLocaleString()}</span>
              </div>
              <div className="flex items-center">
                <Wrench className="h-4 w-4 mr-2 text-gray-400" />
                <span>{workOrder.estimatedDuration} minutes</span>
              </div>
            </div>
          </div>

          {/* Search */}
          <div className="mb-4">
            <input
              type="text"
              placeholder="Search technicians by name or skills..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-primary-500"
            />
          </div>

          {/* Technicians List */}
          <div className="max-h-96 overflow-y-auto space-y-3 mb-6">
            {filteredTechnicians.map((technician) => {
              const distance = calculateDistance(technician);
              const relevantSkills = getRelevantSkills(technician);
              const recommendation = getRecommendationBadge(technician);
              const suitabilityScore = getSuitabilityScore(technician);
              
              return (
                <div
                  key={technician.id}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    selectedTechnicianId === technician.id
                      ? 'border-primary-500 bg-primary-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedTechnicianId(technician.id)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className="h-10 w-10 bg-primary-600 rounded-full flex items-center justify-center text-white font-medium">
                        {technician.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-medium text-gray-900">{technician.name}</h4>
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(technician.status)}`}>
                            {technician.status}
                          </span>
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${recommendation.color}`}>
                            {recommendation.label}
                          </span>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600 mb-2">
                          <div className="flex items-center">
                            <User className="h-4 w-4 mr-1" />
                            <span>{technician.activeWorkOrders.length} active jobs</span>
                          </div>
                          {distance > 0 && (
                            <div className="flex items-center">
                              <MapPin className="h-4 w-4 mr-1" />
                              <span>{distance} miles away</span>
                            </div>
                          )}
                          <div className="flex items-center">
                            <Star className="h-4 w-4 mr-1" />
                            <span>Score: {suitabilityScore}/100</span>
                          </div>
                        </div>

                        {/* Skills */}
                        <div className="flex flex-wrap gap-1">
                          {technician.skills.map(skill => (
                            <span
                              key={skill}
                              className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                                relevantSkills.includes(skill)
                                  ? 'bg-primary-100 text-primary-800 border border-primary-200'
                                  : 'bg-gray-100 text-gray-700'
                              }`}
                            >
                              {skill}
                              {relevantSkills.includes(skill) && (
                                <Star className="h-3 w-3 ml-1 fill-current" />
                              )}
                            </span>
                          ))}
                        </div>

                        {relevantSkills.length > 0 && (
                          <div className="mt-2 text-xs text-green-600">
                            ✓ Has {relevantSkills.length} relevant skill{relevantSkills.length > 1 ? 's' : ''} for this job
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center">
                      <input
                        type="radio"
                        checked={selectedTechnicianId === technician.id}
                        onChange={() => setSelectedTechnicianId(technician.id)}
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredTechnicians.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <User className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p>No technicians found matching your search.</p>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={handleAssign}
              disabled={!selectedTechnicianId}
            >
              Assign Technician
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechnicianAssignmentModal;