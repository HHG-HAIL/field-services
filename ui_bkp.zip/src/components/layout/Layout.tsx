import React from 'react';
import Navigation from './Navigation';
import Header from './Header';
import { User } from '../../types';

interface LayoutProps {
  children: React.ReactNode;
  user: User;
}

const Layout: React.FC<LayoutProps> = ({ children, user }) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation userRole={user.role} />
      <Header user={user} />
      
      <main className="lg:ml-64 pt-4">
        <div className="px-4 sm:px-6 lg:px-8 pb-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;