import React from 'react';

interface StatusBadgeProps {
  status: 'assigned' | 'in-progress' | 'completed' | 'cancelled' | 'available' | 'busy' | 'offline';
  className?: string;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className = '' }) => {
  const getStatusStyles = () => {
    switch (status) {
      case 'completed':
        return 'bg-success-100 text-success-600 border-success-200';
      case 'in-progress':
        return 'bg-primary-100 text-primary-600 border-primary-200';
      case 'assigned':
        return 'bg-warning-100 text-warning-600 border-warning-200';
      case 'cancelled':
        return 'bg-danger-100 text-danger-600 border-danger-200';
      case 'available':
        return 'bg-success-100 text-success-600 border-success-200';
      case 'busy':
        return 'bg-warning-100 text-warning-600 border-warning-200';
      case 'offline':
        return 'bg-gray-100 text-gray-600 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-600 border-gray-200';
    }
  };

  const formatStatus = (status: string) => {
    return status.split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusStyles()} ${className}`}>
      {formatStatus(status)}
    </span>
  );
};

export default StatusBadge;