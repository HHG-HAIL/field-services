import React, { useState } from 'react';
import { Technician } from '../../types';
import Card from '../ui/Card';
import StatusBadge from '../ui/StatusBadge';
import Button from '../ui/Button';
import { Phone, Mail, MapPin, Wrench, Star } from 'lucide-react';

interface TechnicianCardProps {
  technician: Technician;
  onAssignToWorkOrder?: (technicianId: string) => void;
  onUpdateStatus?: (technicianId: string, status: Technician['status']) => void;
  showActions?: boolean;
  workOrderCount?: number;
}

const TechnicianCard: React.FC<TechnicianCardProps> = ({
  technician,
  onAssignToWorkOrder,
  onUpdateStatus,
  showActions = true,
  workOrderCount = 0
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getStatusColor = (status: Technician['status']) => {
    switch (status) {
      case 'available':
        return 'text-green-600 bg-green-50';
      case 'busy':
        return 'text-yellow-600 bg-yellow-50';
      case 'offline':
        return 'text-gray-600 bg-gray-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const getSkillBadge = (skill: string) => {
    const colors: Record<string, string> = {
      'HVAC': 'bg-blue-100 text-blue-800',
      'Electrical': 'bg-yellow-100 text-yellow-800',
      'Plumbing': 'bg-cyan-100 text-cyan-800',
      'Security Systems': 'bg-purple-100 text-purple-800',
      'Mechanical': 'bg-green-100 text-green-800',
      'General Maintenance': 'bg-gray-100 text-gray-800'
    };
    
    return colors[skill] || 'bg-gray-100 text-gray-800';
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-200">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="h-12 w-12 bg-primary-600 rounded-full flex items-center justify-center text-white font-semibold text-lg">
              {technician.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">{technician.name}</h3>
              <StatusBadge status={technician.status} />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`p-2 rounded-full ${getStatusColor(technician.status)}`}>
              <div className="w-3 h-3 rounded-full bg-current"></div>
            </div>
          </div>
        </div>

        {/* Quick Info */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center text-gray-600">
            <Wrench className="h-4 w-4 mr-2" />
            <span>{technician.activeWorkOrders.length} active jobs</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Star className="h-4 w-4 mr-2" />
            <span>{technician.skills.length} skills</span>
          </div>
        </div>

        {/* Skills */}
        <div>
          <div className="flex flex-wrap gap-2">
            {technician.skills.slice(0, isExpanded ? undefined : 3).map((skill) => (
              <span
                key={skill}
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getSkillBadge(skill)}`}
              >
                {skill}
              </span>
            ))}
            {technician.skills.length > 3 && !isExpanded && (
              <button
                onClick={() => setIsExpanded(true)}
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600 hover:bg-gray-200"
              >
                +{technician.skills.length - 3} more
              </button>
            )}
          </div>
        </div>

        {/* Contact Info (Expanded) */}
        {isExpanded && (
          <div className="space-y-2 pt-2 border-t border-gray-200">
            <div className="flex items-center text-sm text-gray-600">
              <Mail className="h-4 w-4 mr-2" />
              <span>{technician.email}</span>
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <Phone className="h-4 w-4 mr-2" />
              <span>{technician.phone}</span>
            </div>
            {technician.currentLocation && (
              <div className="flex items-center text-sm text-gray-600">
                <MapPin className="h-4 w-4 mr-2" />
                <span>
                  {technician.currentLocation.lat.toFixed(4)}, {technician.currentLocation.lng.toFixed(4)}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        {showActions && (
          <div className="flex flex-wrap gap-2 pt-2 border-t border-gray-200">
            {!isExpanded && (
              <Button
                size="sm"
                variant="secondary"
                onClick={() => setIsExpanded(true)}
              >
                View Details
              </Button>
            )}
            
            {isExpanded && (
              <Button
                size="sm"
                variant="secondary"
                onClick={() => setIsExpanded(false)}
              >
                Hide Details
              </Button>
            )}

            {technician.status === 'available' && onAssignToWorkOrder && (
              <Button
                size="sm"
                variant="primary"
                onClick={() => onAssignToWorkOrder(technician.id)}
              >
                Assign to Job
              </Button>
            )}

            {onUpdateStatus && (
              <div className="flex gap-1">
                {technician.status !== 'available' && (
                  <Button
                    size="sm"
                    variant="success"
                    onClick={() => onUpdateStatus(technician.id, 'available')}
                  >
                    Mark Available
                  </Button>
                )}
                {technician.status !== 'offline' && (
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => onUpdateStatus(technician.id, 'offline')}
                  >
                    Set Offline
                  </Button>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  );
};

export default TechnicianCard;