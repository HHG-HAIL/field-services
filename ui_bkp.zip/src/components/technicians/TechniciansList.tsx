import React, { useState } from 'react';
import { Technician } from '../../types';
import TechnicianCard from './TechnicianCard';
import { Search, Plus, Users } from 'lucide-react';
import Button from '../ui/Button';

interface TechniciansListProps {
  technicians: Technician[];
  onAssignToWorkOrder?: (technicianId: string) => void;
  onUpdateStatus?: (technicianId: string, status: Technician['status']) => void;
  onCreateNew?: () => void;
  title?: string;
}

const TechniciansList: React.FC<TechniciansListProps> = ({
  technicians,
  onAssignToWorkOrder,
  onUpdateStatus,
  onCreateNew,
  title = "Technicians"
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [skillFilter, setSkillFilter] = useState<string>('all');

  const filteredTechnicians = technicians.filter(technician => {
    const matchesSearch = 
      technician.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      technician.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      technician.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = statusFilter === 'all' || technician.status === statusFilter;
    const matchesSkill = skillFilter === 'all' || technician.skills.includes(skillFilter);
    
    return matchesSearch && matchesStatus && matchesSkill;
  });

  const getStatusCounts = () => {
    return {
      all: technicians.length,
      available: technicians.filter(t => t.status === 'available').length,
      busy: technicians.filter(t => t.status === 'busy').length,
      offline: technicians.filter(t => t.status === 'offline').length,
    };
  };

  const getAllSkills = () => {
    const skills = new Set<string>();
    technicians.forEach(tech => {
      tech.skills.forEach(skill => skills.add(skill));
    });
    return Array.from(skills).sort();
  };

  const statusCounts = getStatusCounts();
  const allSkills = getAllSkills();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
          <p className="text-gray-600 mt-1">
            {statusCounts.available} available • {statusCounts.busy} busy • {statusCounts.offline} offline
          </p>
        </div>
        {onCreateNew && (
          <Button onClick={onCreateNew}>
            <Plus className="h-4 w-4 mr-2" />
            Add Technician
          </Button>
        )}
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search technicians, skills..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
          </div>
          
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="all">All Status ({statusCounts.all})</option>
              <option value="available">Available ({statusCounts.available})</option>
              <option value="busy">Busy ({statusCounts.busy})</option>
              <option value="offline">Offline ({statusCounts.offline})</option>
            </select>
          </div>
          
          <div>
            <select
              value={skillFilter}
              onChange={(e) => setSkillFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="all">All Skills</option>
              {allSkills.map(skill => (
                <option key={skill} value={skill}>{skill}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Technicians Grid */}
      {filteredTechnicians.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-gray-200">
          <Users className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No technicians found</h3>
          <p className="mt-1 text-sm text-gray-500">
            Try adjusting your search or filters to find what you're looking for.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredTechnicians.map((technician) => (
            <TechnicianCard
              key={technician.id}
              technician={technician}
              onAssignToWorkOrder={onAssignToWorkOrder}
              onUpdateStatus={onUpdateStatus}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default TechniciansList;