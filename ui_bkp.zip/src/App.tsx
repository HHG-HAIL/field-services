import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import SchedulePage from './pages/SchedulePage';
import TechniciansPage from './pages/TechniciansPage';
import WorkOrderList from './components/workorders/WorkOrderList';
import CreateWorkOrderModal from './components/workorders/CreateWorkOrderModal';
import TechnicianAssignmentModal from './components/workorders/TechnicianAssignmentModal';
import EditWorkOrderModal from './components/workorders/EditWorkOrderModal';
import ChangeTechnicianModal from './components/workorders/ChangeTechnicianModal';
import { mockWorkOrders, mockTechnicians, mockUsers, mockCustomers } from './data/mockData';
import { WorkOrder, User, Technician } from './types';
import './App.css';

function App() {
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(mockWorkOrders);
  const [technicians, setTechnicians] = useState<Technician[]>(mockTechnicians);
  const [currentUser] = useState<User>(mockUsers[0]); // Default to dispatcher
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAssignmentModal, setShowAssignmentModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showChangeTechnicianModal, setShowChangeTechnicianModal] = useState(false);
  const [selectedWorkOrder, setSelectedWorkOrder] = useState<WorkOrder | null>(null);
  const [workOrderToEdit, setWorkOrderToEdit] = useState<WorkOrder | null>(null);
  const [workOrderToReassign, setWorkOrderToReassign] = useState<WorkOrder | null>(null);

  const handleStatusChange = (workOrderId: string, newStatus: WorkOrder['status']) => {
    setWorkOrders(prevOrders =>
      prevOrders.map(order =>
        order.id === workOrderId
          ? { ...order, status: newStatus, updatedAt: new Date().toISOString() }
          : order
      )
    );
    
    // Update technician status if work order is completed
    if (newStatus === 'completed' || newStatus === 'cancelled') {
      const workOrder = workOrders.find(wo => wo.id === workOrderId);
      if (workOrder?.technicianId) {
        setTechnicians(prevTechs =>
          prevTechs.map(tech =>
            tech.id === workOrder.technicianId
              ? { 
                  ...tech, 
                  activeWorkOrders: tech.activeWorkOrders.filter(id => id !== workOrderId),
                  status: tech.activeWorkOrders.length <= 1 ? 'available' : 'busy'
                }
              : tech
          )
        );
      }
    }
    
    console.log(`Work order ${workOrderId} status changed to ${newStatus}`);
  };

  const handleAssignTechnician = (workOrderId: string) => {
    const workOrder = workOrders.find(wo => wo.id === workOrderId);
    if (workOrder) {
      setSelectedWorkOrder(workOrder);
      setShowAssignmentModal(true);
    }
  };

  const handleTechnicianAssignment = (technicianId: string) => {
    if (!selectedWorkOrder) return;

    const technician = technicians.find(t => t.id === technicianId);
    if (technician) {
      // Update work order
      setWorkOrders(prevOrders =>
        prevOrders.map(order =>
          order.id === selectedWorkOrder.id
            ? { 
                ...order, 
                technicianId: technician.id,
                technicianName: technician.name,
                status: 'assigned',
                updatedAt: new Date().toISOString()
              }
            : order
        )
      );

      // Update technician
      setTechnicians(prevTechs =>
        prevTechs.map(tech =>
          tech.id === technicianId
            ? { 
                ...tech, 
                activeWorkOrders: [...tech.activeWorkOrders, selectedWorkOrder.id],
                status: 'busy'
              }
            : tech
        )
      );

      console.log(`Assigned technician ${technician.name} to work order ${selectedWorkOrder.id}`);
      setSelectedWorkOrder(null);
    }
  };

  const handleCreateWorkOrder = (workOrderData: Omit<WorkOrder, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newWorkOrder: WorkOrder = {
      ...workOrderData,
      id: (workOrders.length + 1).toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setWorkOrders(prev => [...prev, newWorkOrder]);

    // If technician is assigned, update their status
    if (workOrderData.technicianId) {
      setTechnicians(prevTechs =>
        prevTechs.map(tech =>
          tech.id === workOrderData.technicianId
            ? { 
                ...tech, 
                activeWorkOrders: [...tech.activeWorkOrders, newWorkOrder.id],
                status: 'busy'
              }
            : tech
        )
      );
    }

    console.log('Created new work order:', newWorkOrder.title);
  };

  const handleUpdateTechnicianStatus = (technicianId: string, status: Technician['status']) => {
    setTechnicians(prevTechs =>
      prevTechs.map(tech =>
        tech.id === technicianId ? { ...tech, status } : tech
      )
    );
    console.log(`Technician ${technicianId} status updated to ${status}`);
  };

  const handleTechnicianWorkOrderAssignment = (technicianId: string, workOrderId?: string) => {
    if (workOrderId) {
      const workOrder = workOrders.find(wo => wo.id === workOrderId);
      const technician = technicians.find(t => t.id === technicianId);
      
      if (workOrder && technician) {
        handleTechnicianAssignment(technicianId);
      }
    }
  };

  const handleReschedule = (workOrderId: string, newDate: string) => {
    setWorkOrders(prevOrders =>
      prevOrders.map(order =>
        order.id === workOrderId
          ? { ...order, scheduledDate: new Date(newDate).toISOString(), updatedAt: new Date().toISOString() }
          : order
      )
    );
    console.log(`Rescheduled work order ${workOrderId} to ${newDate}`);
  };

  // New handlers for editing work orders and managing technicians
  const handleEditWorkOrder = (workOrder: WorkOrder) => {
    setWorkOrderToEdit(workOrder);
    setShowEditModal(true);
  };

  const handleUpdateWorkOrder = (workOrderId: string, updates: Partial<WorkOrder>) => {
    const originalWorkOrder = workOrders.find(wo => wo.id === workOrderId);
    const updatedWorkOrder = { ...originalWorkOrder, ...updates } as WorkOrder;

    setWorkOrders(prevOrders =>
      prevOrders.map(order =>
        order.id === workOrderId ? updatedWorkOrder : order
      )
    );

    // Handle technician assignment changes
    if (originalWorkOrder?.technicianId !== updates.technicianId) {
      // Remove from old technician
      if (originalWorkOrder?.technicianId) {
        setTechnicians(prevTechs =>
          prevTechs.map(tech =>
            tech.id === originalWorkOrder.technicianId
              ? { 
                  ...tech, 
                  activeWorkOrders: tech.activeWorkOrders.filter(id => id !== workOrderId),
                  status: tech.activeWorkOrders.length <= 1 ? 'available' : 'busy'
                }
              : tech
          )
        );
      }

      // Add to new technician
      if (updates.technicianId) {
        setTechnicians(prevTechs =>
          prevTechs.map(tech =>
            tech.id === updates.technicianId
              ? { 
                  ...tech, 
                  activeWorkOrders: [...tech.activeWorkOrders, workOrderId],
                  status: 'busy'
                }
              : tech
          )
        );
      }
    }

    setShowEditModal(false);
    setWorkOrderToEdit(null);
    console.log(`Updated work order ${workOrderId}`);
  };

  const handleChangeTechnician = (workOrder: WorkOrder) => {
    setWorkOrderToReassign(workOrder);
    setShowChangeTechnicianModal(true);
  };

  const handleTechnicianChange = (workOrderId: string, newTechnicianId: string | null) => {
    const workOrder = workOrders.find(wo => wo.id === workOrderId);
    const newTechnician = newTechnicianId ? technicians.find(t => t.id === newTechnicianId) : null;

    if (workOrder) {
      // Remove from old technician
      if (workOrder.technicianId) {
        setTechnicians(prevTechs =>
          prevTechs.map(tech =>
            tech.id === workOrder.technicianId
              ? { 
                  ...tech, 
                  activeWorkOrders: tech.activeWorkOrders.filter(id => id !== workOrderId),
                  status: tech.activeWorkOrders.length <= 1 ? 'available' : 'busy'
                }
              : tech
          )
        );
      }

      // Update work order
      setWorkOrders(prevOrders =>
        prevOrders.map(order =>
          order.id === workOrderId
            ? { 
                ...order, 
                technicianId: newTechnicianId || undefined,
                technicianName: newTechnician?.name || undefined,
                status: newTechnicianId ? 'assigned' : 'assigned',
                updatedAt: new Date().toISOString()
              }
            : order
        )
      );

      // Add to new technician
      if (newTechnicianId) {
        setTechnicians(prevTechs =>
          prevTechs.map(tech =>
            tech.id === newTechnicianId
              ? { 
                  ...tech, 
                  activeWorkOrders: [...tech.activeWorkOrders, workOrderId],
                  status: 'busy'
                }
              : tech
          )
        );
      }
    }

    setShowChangeTechnicianModal(false);
    setWorkOrderToReassign(null);
    console.log(`Changed technician for work order ${workOrderId} to ${newTechnicianId || 'unassigned'}`);
  };

  const handleCreateTechnician = (technicianData: Omit<Technician, 'id'>) => {
    const newTechnician: Technician = {
      ...technicianData,
      id: (technicians.length + 1).toString()
    };

    setTechnicians(prev => [...prev, newTechnician]);
    console.log('Created new technician:', newTechnician.name);
  };

  return (
    <Router>
      <Layout user={currentUser}>
        <Routes>
          <Route 
            path="/" 
            element={
              <Dashboard
                workOrders={workOrders}
                technicians={technicians}
                userRole={currentUser.role}
                onStatusChange={handleStatusChange}
                onAssignTechnician={handleAssignTechnician}
                onEditWorkOrder={handleEditWorkOrder}
                onChangeTechnician={handleChangeTechnician}
              />
            } 
          />
          <Route 
            path="/work-orders" 
            element={
              <WorkOrderList
                workOrders={workOrders}
                onStatusChange={handleStatusChange}
                onAssignTechnician={handleAssignTechnician}
                onEditWorkOrder={handleEditWorkOrder}
                onChangeTechnician={handleChangeTechnician}
                onCreateNew={() => setShowCreateModal(true)}
              />
            } 
          />
          <Route 
            path="/schedule" 
            element={
              <SchedulePage
                workOrders={workOrders}
                technicians={technicians}
                onStatusChange={handleStatusChange}
                onReschedule={handleReschedule}
              />
            } 
          />
          <Route 
            path="/technicians" 
            element={
              <TechniciansPage
                technicians={technicians}
                workOrders={workOrders}
                onUpdateTechnicianStatus={handleUpdateTechnicianStatus}
                onAssignTechnician={handleTechnicianWorkOrderAssignment}
                onCreateTechnician={handleCreateTechnician}
              />
            } 
          />
          <Route 
            path="/my-jobs" 
            element={
              <WorkOrderList
                workOrders={workOrders.filter(wo => wo.technicianId === currentUser.id)}
                onStatusChange={handleStatusChange}
                onEditWorkOrder={handleEditWorkOrder}
                onChangeTechnician={handleChangeTechnician}
                title="My Jobs"
                showActions={true}
              />
            } 
          />
          <Route 
            path="/my-schedule" 
            element={
              <SchedulePage
                workOrders={workOrders.filter(wo => wo.technicianId === currentUser.id)}
                technicians={technicians}
                onStatusChange={handleStatusChange}
                onReschedule={handleReschedule}
              />
            } 
          />
          {/* Placeholder routes for other pages */}
          <Route path="/map" element={<div className="p-6 text-center">Map View - Coming Soon</div>} />
          <Route path="/analytics" element={<div className="p-6 text-center">Analytics - Coming Soon</div>} />
          <Route path="/reports" element={<div className="p-6 text-center">Reports - Coming Soon</div>} />
        </Routes>

        {/* Modals */}
        <CreateWorkOrderModal
          isOpen={showCreateModal}
          onClose={() => setShowCreateModal(false)}
          onSubmit={handleCreateWorkOrder}
          technicians={technicians}
          customers={mockCustomers}
        />

        <TechnicianAssignmentModal
          isOpen={showAssignmentModal}
          onClose={() => {
            setShowAssignmentModal(false);
            setSelectedWorkOrder(null);
          }}
          onAssign={handleTechnicianAssignment}
          technicians={technicians}
          workOrder={selectedWorkOrder}
        />

        <EditWorkOrderModal
          isOpen={showEditModal}
          workOrder={workOrderToEdit}
          customers={mockCustomers}
          technicians={technicians}
          onClose={() => {
            setShowEditModal(false);
            setWorkOrderToEdit(null);
          }}
          onUpdateWorkOrder={handleUpdateWorkOrder}
        />

        <ChangeTechnicianModal
          isOpen={showChangeTechnicianModal}
          workOrder={workOrderToReassign}
          technicians={technicians}
          onClose={() => {
            setShowChangeTechnicianModal(false);
            setWorkOrderToReassign(null);
          }}
          onChangeTechnician={handleTechnicianChange}
        />
      </Layout>
    </Router>
  );
}

export default App;
